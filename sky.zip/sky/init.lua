minetest.register_on_joinplayer(function(player)
      minetest.setting_set("enable_clouds", 0)
end)

local skytextures = {
   "sky_pos_1.png",
   "sky_pos_2.png",
   "sky_pos_3.png",
   "sky_pos_4.png",
   "sky_pos_5.png",
   "sky_pos_6.png",
}

--Sky textures
minetest.register_on_joinplayer(function(player)
      minetest.after(0, function()
                        player:set_sky({r=0, g=0, b=0, a=0},
                           "skybox", skytextures)
      end)
end)
