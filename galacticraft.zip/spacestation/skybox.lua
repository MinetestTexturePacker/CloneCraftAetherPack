

minetest.register_on_joinplayer(function(player)
   local skyTexBase = "sky_"
   player:set_sky("#000000", "skybox", {
               skyTexBase .. "1.png",
               skyTexBase .. "2.png",
               skyTexBase .. "3.png",
               skyTexBase .. "4.png",
               skyTexBase .. "5.png",
               skyTexBase .. "6.png",
      }, false)
end)

